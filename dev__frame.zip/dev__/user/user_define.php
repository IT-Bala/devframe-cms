<?php
# PHP Dev__ FRAMEWORK
#========== USER DEFINE SECTION ==========#
class user_define { 
	public function Level($var){
		return "Level 1 is running and $var!";
	}
}