<?php
// PHP Dev__ FRAMEWORK
// START INTEGRATION 
class user{
	public $get;public function __construct(){ $this->get = new common;}
}
// END INTEGRATION