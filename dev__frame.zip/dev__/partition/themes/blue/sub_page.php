<h2><?php echo $title; ?></h2>
<p><?php echo $content; ?></p>
<?php
#echo connect_plugin("Newsletter");
?>

