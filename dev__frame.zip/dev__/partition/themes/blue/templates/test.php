<?php get_header(); ?>
Welcome to test <?php echo "demo file"; ?>
<?php get_footer();?>