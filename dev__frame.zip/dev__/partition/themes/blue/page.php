<h1>Blue theme is running</h1>
<?php
echo connect_plugin("");
#connect_module('shipping');