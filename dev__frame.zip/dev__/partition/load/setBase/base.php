<?php
// PHP dev__ FRAMEWORK

###############################
#                             #
#  DON'T EDIT THIS DEFINED    #
#                             #
###############################

/*###################### IT IS COMMON DEFINE FUNCTION FOR EVERY  THEME  ######################*/
define('THEME_HEADER','/section/header.php');     
define('THEME_PAGE','/page.php');                 
define('THEME_FOOTER','/section/footer.php');     
define('INTER','partition/load/');
define('STATUS','partition/status/');
define('BASE_URL','partition/themes/'.THEME_BASE);
/*###################### IT IS COMMON DEFINE FUNCTION FOR EVERY  THEME  ######################*/