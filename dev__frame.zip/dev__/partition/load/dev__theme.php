<?php
// PHP Dev__ framework
require_once('setBase/load.php');
class dev__theme{}
#####################

#  THEME CONNECTION #

#####################
$Mytheme = new Mytheme;
$Mytheme->connect();