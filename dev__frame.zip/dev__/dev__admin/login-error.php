<?php
// PHP dev__ FRAMEWORK
?>
<link rel="stylesheet" href="login.css">
<script type="text/javascript" src="login.js"></script>
<body>
<div class="logo">
<a href="#">
<h1><img src="img/logo.png" /></h1>
</a>
</div>
<div class="form">
<h1>Sign in</h1>
<div class="line"></div>
<div class="login_error">
<span class="error"><h2>Login error occured, please try again !</h2></span>
</div>
<form id="sign-in-form" class="input-form" action="index.php" method="post">
<input class="btn-sign-in btn-orange" type="submit" value="Back">
</form>
</div>
</body>