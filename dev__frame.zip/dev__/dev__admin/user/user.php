<?php
class admin extends common{
		// You can create user define function			
}
$admin = new admin;
?>