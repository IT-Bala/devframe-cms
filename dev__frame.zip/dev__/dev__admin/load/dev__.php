<?php
// PHP dev__ FRAMEWORK LOAD
inc('./user/left_menu');
inc('./user/page_assign');
inc('./user/common');
inc('./user/user');
inc('./section/section');
?>
