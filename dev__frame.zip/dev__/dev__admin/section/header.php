<!DOCTYPE html>
<html lang="en">
    <head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Dev__ Admin Panel</title>
<script src="js/google-ajax.js"></script>
<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
<script src="ckeditor/ckeditor.js"></script>
<script src="ckeditor/samples/sample.js"></script>    
<script src="js/dev_.js"></script>
<link rel="stylesheet" href="editor/sample.css">
<link rel="stylesheet" href="css/reset.css" type="text/css" charset="utf-8">
<link rel="stylesheet" href="css/core.css" type="text/css" charset="utf-8">
<link rel="stylesheet" href="css/accordion.core.css" type="text/css" charset="utf-8">
</head>
<body>
<div id="page">
<div id="header"><?php require_once('top_menu.php'); ?></div>
<div id="page_center">
     
      