<?php
echo "<p style='padding:20px; border:1px #eee solid; box-shadow:1px 1px 6px #ccc; color:#F00; margin:auto; text-align:center;'>404 Request page error !</p>"; 
?>
