<?php
// File name must be index.php inside of this class
// Class name must be theme_admin => left_menu and page 
class Nivo_Slider_Admin{
	public function left_menu(){
		$menu = array(
			'Nivo Slider' => array('<a href="?Nivo_Slider_Admin=myslider&Nivo Slider">My Slider</a>','<a href="?Nivo_Slider_Admin=add_slider&Nivo Slider">Add New Image</a>')
			);
	return $menu;
	}
	public function page(){
		
			$plugin_page = $_REQUEST['Nivo_Slider_Admin'];
			switch($plugin_page){
				case 'myslider':
				$plugin_page = include 'myslider.php';
				break;
				case 'add_slider':
				$plugin_page = include 'addslider.php';
				break;
			}
		
		return $plugin_page;
	}
	
}
$GLOBALS['plugin_admin'][] = 'Nivo_Slider_Admin';
