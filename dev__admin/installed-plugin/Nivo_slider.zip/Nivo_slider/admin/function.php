<?php
function current_theme_url(){
	return '../'.THEME_PATH_PREFIX().THEME_BASE().'/'.basename(__DIR__).'/';
}
function tables(){
	query("CREATE TABLE IF NOT EXISTS ".DATABASE.".".DB_PREFIX."slider (
		`slider_id` INT NOT NULL AUTO_INCREMENT ,
		`slider_name` VARCHAR( 255 ) NOT NULL ,
		`slider_image` VARCHAR( 255 ) NOT NULL ,
		`slider_date` VARCHAR( 255 ) NOT NULL ,
		`status` VARCHAR( 255 ) NOT NULL ,
		PRIMARY KEY ( `slider_id` )
		) ENGINE = InnoDB");
}
function slider(){ $arg = '';
	if($arg = func_get_args()){ $arg=' where slider_id='.$arg[0];}
	return select(DB_PREFIX."slider".$arg);
}
function add_slider(){ $msg ='';
    if(!empty($_FILES['slider_image']['name'])){ move_uploaded_file($_FILES['slider_image']['tmp_name'],'../images/'.$_FILES['slider_image']['name']);}
    if(!empty($_REQUEST['slider_name'])){
	if(query("insert into ".DB_PREFIX."slider set 
	slider_name = '".$_REQUEST['slider_name']."',
	slider_image = '".$_FILES['slider_image']['name']."',
	slider_date = now(),
	status = '1'
	")){
		$msg = success('Slider images has add successfully!');
	}}else{ $msg = error('Please fill required fields!');}
	return $msg;
}
function update_slider(){
	$img = $_REQUEST['slider_name_'];
	if(!empty($_FILES['slider_image']['name'])){ move_uploaded_file($_FILES['slider_image']['tmp_name'],'../images/'.$_FILES['slider_image']['name']);
	$img = $_FILES['slider_image']['name'];}
	if(!empty($_REQUEST['slider_name'])){
	if(query("update ".DB_PREFIX."slider set 
	slider_name = '".$_REQUEST['slider_name']."',
	slider_image = '".$img."',
	slider_date = now() where slider_id='".$_REQUEST['slider_id']."'
	")){
		$msg = success('Slider images has been updated successfully!');
	}}else{ $msg=error('Please fill required fields!');}
	return $msg;
}
function delete_slider(){$msg='';
		if(isset($_REQUEST['delete_slider_img'])&& ($_REQUEST['delete_slider_img']!='')){ $id = $_REQUEST['delete_slider_img'];
			if(query("delete from ".DB_PREFIX."slider where slider_id=".$id)){
				$msg = success("Slider image has been deleted !");
			}			
		}return $msg;
	}