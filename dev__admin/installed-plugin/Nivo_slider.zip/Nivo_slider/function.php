<?php
if(!function_exists('getSlider')){
	function getSlider(){$slider=array();
		$sql= select(DB_PREFIX."slider");
		while($f=fetch($sql)){ $slider[]=$f;}
		return $slider;
	}
}