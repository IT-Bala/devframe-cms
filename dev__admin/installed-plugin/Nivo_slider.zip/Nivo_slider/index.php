<link rel="stylesheet" href="<?=plugin_base().basename(__DIR__);?>/css/nivo-slider.css" type="text/css" />
<script src="<?=plugin_base().basename(__DIR__);?>/js/min.js" type="application/javascript"></script>
<script src="<?=plugin_base().basename(__DIR__);?>/js/nivo-slider.js" type="application/javascript"></script>
<?php include('function.php'); ?>
<div id="slider">
<?php foreach(getSlider() as $slider){ ?>     
      <img src="images/<?=$slider->slider_image;?>" alt="" title="<?=$slider->slider_name;?>"  /> 
<?php } ?>  
</div><!-- end slider div-->
<script type="text/javascript"> $(window).load(function() 
{     $('#slider').nivoSlider({effect:'sliceDownLeft',
directionNavHide:false,
prevText: 'Prev',  
nextText: 'Next', 
   });  }); </script> 
  <div class="clear"></div> 
